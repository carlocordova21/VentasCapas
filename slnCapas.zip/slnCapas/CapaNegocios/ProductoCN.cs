﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CapaEntidad;
using CapaDatos;
namespace CapaNegocios
{
    public class ProductoCN
    {
        public ProductoCE buscarId(int id)
        {
            //Instanciar ProductoCD
            ProductoCD productoCD = new ProductoCD();
            //Ejecutar el metodo que corresponde
            ProductoCE productoCE = productoCD.buscarId(id);
            //Devolver el resultado
            return productoCE;
        }

        public List<ProductoCE> buscarDescripcion(string descripcion)
        {
            ProductoCD productoCD = new ProductoCD();
            List<ProductoCE> listaProductosCE = productoCD.buscarDescripcion(descripcion);
            return listaProductosCE;
        }

        public int insertar(ProductoCE productoCE)
        {
            ProductoCD productoCD = new ProductoCD();
            int nuevoId = productoCD.insertar(productoCE);
            return nuevoId;
        }

        public bool actualizar(ProductoCE productoCE)
        {
            ProductoCD productoCD = new ProductoCD();
            bool estado = productoCD.actualizar(productoCE);
            return estado;
        }

        public bool eliminar(int id)
        {
            ProductoCD productoCD = new ProductoCD();
            bool estado = productoCD.eliminar(id);
            return estado;
        }
    }
}
