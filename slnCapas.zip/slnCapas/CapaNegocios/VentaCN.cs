﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using CapaDatos;
using CapaEntidad;
namespace CapaNegocios
{
    public class VentaCN
    {
        public int insertar(VentaCE ventaCE)
        {
            VentaCD ventaCD = new VentaCD();
            int nuevoId = ventaCD.insertar(ventaCE);
            return nuevoId;
        }
    }
}
