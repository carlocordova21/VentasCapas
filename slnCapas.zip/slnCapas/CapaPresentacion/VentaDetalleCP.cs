﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using CapaNegocios;
using CapaEntidad;
namespace CapaPresentacion
{
    public partial class VentaDetalleCP : Form
    {
        private static VentaDetalleCP instancia = null;

        public static VentaDetalleCP Instancia 
        { 
            get
            {
                if (instancia == null || instancia.IsDisposed == true)
                {
                    instancia = new VentaDetalleCP();
                }
                return instancia;
            } 
        }

        public VentaDetalleCP()
        {
            InitializeComponent();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            DateTime fechaActual = DateTime.Now;
            txtFecha.Text = fechaActual.ToString();
        }

        private void btnBuscarCliente_Click(object sender, EventArgs e)
        {
            //Instanciar el ClienteCP
            ClienteCP clienteCP = new ClienteCP();
            //Mostrar la instancia
            clienteCP.ShowDialog(); //MODAL - PAUSA

            //Recoger los valores de las cajas de texto
            //para enviarlos al otro formulario
            txtIdCliente.Text = clienteCP.Controls["txtId"].Text;
            txtRucCliente.Text = clienteCP.Controls["txtRuc"].Text;
            txtNombreCliente.Text = clienteCP.Controls["txtNombre"].Text;
        }

        private void btnBuscarProducto_Click(object sender, EventArgs e)
        {
            //Instanciar el ClienteCP
            ProductoCP productoCP = new ProductoCP();
            //Mostrar la instancia
            productoCP.ShowDialog(); //MODAL - PAUSA

            //Recoger los valores de las cajas de texto
            //para enviarlos al otro formulario
            txtIdProducto.Text = productoCP.Controls["txtId"].Text;
            txtNombreProducto.Text = productoCP.Controls["txtDescripcion"].Text;
            txtPrecioProducto.Text = productoCP.Controls["txtPrecio"].Text;
        }

        private void txtIdProducto_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Tab)
            {
                //Leer el ID que se ingreso
                int id = (txtIdProducto.Text.Length>0)?Convert.ToInt32(txtIdProducto.Text):0;
                //Instanciar ClienteCN
                ProductoCN productoCN = new ProductoCN();
                ProductoCE productoCE = productoCN.buscarId(id);

                txtIdProducto.Text = productoCE.Id.ToString();
                txtNombreProducto.Text = productoCE.Descripcion;
                txtPrecioProducto.Text = productoCE.Precio.ToString("N2");
            }
        }

        private void txtIdCliente_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyCode == Keys.Tab)
            {
                //Leer el ID que se ingreso
                int id = (txtIdCliente.Text.Length > 0) ? Convert.ToInt32(txtIdCliente.Text) : 0;
                //Instanciar ClienteCN
                ClienteCN clienteCN = new ClienteCN();
                ClienteCE clienteCE = clienteCN.buscarId(id);

                txtIdCliente.Text = clienteCE.Id.ToString();
                txtRucCliente.Text = clienteCE.Numruc;
                txtNombreCliente.Text = clienteCE.Nombre;
            }
        }

        private void VentaDetalleCP_Load(object sender, EventArgs e)
        {
            dgvDetalle.Columns.Add("colIdProducto", "CODIGO");
            dgvDetalle.Columns.Add("colDescripcion", "DESCRIPCION");
            dgvDetalle.Columns.Add("colPrecio", "PRECIO S/.");
            dgvDetalle.Columns.Add("colCantidad", "CANTIDAD");
            dgvDetalle.Columns.Add("colTotal", "TOTAL S/.");

            dgvDetalle.AllowUserToAddRows = false;
        }

        private void btnAgregarDetalle_Click(object sender, EventArgs e)
        {
            int idProducto = Convert.ToInt32(txtIdProducto.Text);
            string descripcion = txtNombreProducto.Text;
            double precio = Convert.ToDouble(txtPrecioProducto.Text);
            int cantidad = Convert.ToInt32(numCantidad.Value);
            double total = precio * cantidad;

            if (idProducto > 0 && cantidad > 0 && descripcion.Length > 0)
            {
                dgvDetalle.Rows.Add(idProducto, descripcion, precio, cantidad, total);

                calcularTotal();
                resetFila();
            }
        }

        public void resetFila()
        {
            txtIdProducto.Text = "0";
            txtNombreProducto.Text = "";
            txtPrecioProducto.Text = "0";
            numCantidad.Value = 0;
        }

        private void resetControl()
        {
            resetFila();
            txtIdCliente.Text = "0";
            txtRucCliente.Text = "";
            txtNombreCliente.Text = "";
            txtTotal.Text = "0.00";

            dgvDetalle.Rows.Clear();
        }

        private void calcularTotal()
        {
            //txtTotal.Text = dgvDetalle.Rows[0].Cells["colTotal"].Value.ToString();
            double total = 0;
            foreach (DataGridViewRow fila in dgvDetalle.Rows)
            {
                total += Convert.ToDouble(fila.Cells["colTotal"].Value);
            }
            txtTotal.Text = total.ToString("N2");

        }

        private void btnGuardarVenta_Click(object sender, EventArgs e)
        {
            if (dgvDetalle.Rows.Count > 0)
            {
                DialogResult rpta = MessageBox.Show("Esta a punto de registrar " +
                    "una venta, esta seguro?", "Guardar", MessageBoxButtons.YesNo,
                    MessageBoxIcon.Information, MessageBoxDefaultButton.Button2);

                if (rpta == DialogResult.Yes)
                {
                    //Fase I: Insertar venta
                    //Declarar la variable para la venta
                    int idVenta = 0;
                    DateTime fecVenta = DateTime.Now;
                    int idCliente = Convert.ToInt32(txtIdCliente.Text);

                    //Instanciar una VentaCE
                    VentaCE ventaCE = new VentaCE(idVenta, fecVenta, idCliente);
                    //Instanciar una VentaCN
                    VentaCN ventaCN = new VentaCN();
                    //Ejecutar la insercion de la VENTA
                    idVenta = ventaCN.insertar(ventaCE);

                    //Fase II: Insertar Detalle
                    foreach (DataGridViewRow fila in dgvDetalle.Rows)
                    {
                        //Leer los valores de cada fila
                        int idProducto = Convert.ToInt32(fila.Cells["colIdProducto"].Value);
                        int cantidad = Convert.ToInt32(fila.Cells["colCantidad"].Value);

                        //Instanciar un DetalleCE
                        DetalleCE detalleCE = new DetalleCE(0, idVenta, idProducto, cantidad);
                        //Instanciar un DetalleCN
                        DetalleCN detalleCN = new DetalleCN();
                        detalleCN.insertar(detalleCE);
                    }

                    MessageBox.Show("La venta ha sido registrada.");
                    resetControl();
                }
            }

            
             
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
