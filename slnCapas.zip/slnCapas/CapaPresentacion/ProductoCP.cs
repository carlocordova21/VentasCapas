﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using CapaEntidad;
using CapaNegocios;
namespace CapaPresentacion
{
    /*
     * 
     * PATRON DE DISENO SINGLETON
     * 
     * 
     */
    public partial class ProductoCP : Form
    {
        //PASO 1: Declarar una propiedad para declarar las instancias
        // La propiedad debera ser de la misma clase
        // Debera tener como valor predeterminado: null
        // Debera ser estatica para acceder sin necesidad de instancia

        private static ProductoCP instancia = null;

        //PASO 2: Encapsular la propiedad: instancia
        public static ProductoCP Instancia 
        {
            get 
            { 
                //Si la instancia es NULA o ha sido eliminada
                if (instancia == null || instancia.IsDisposed == true)
                {
                    //Instanciar la clase
                    instancia = new ProductoCP();
                }
                return instancia;
            }
        }

        //PASO 3: ...Se realiza en el momento de llamar a la clase
        //En el evento click del menu

        public ProductoCP()
        {
            InitializeComponent();
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            //Instanciar capa negocio
            ProductoCN productoCN = new ProductoCN();
            //Ejecutar el metodo de busqueda
            string valorBuscado = txtBuscar.Text;
            List<ProductoCE> listaProductosCE = productoCN.buscarDescripcion(valorBuscado);
            dgvProductos.DataSource = listaProductosCE;
        }

        private void dgvProductos_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvProductos.SelectedRows.Count > 0)
            {
                DataGridViewRow filaSel = dgvProductos.SelectedRows[0];
                int id = Convert.ToInt32(filaSel.Cells["id"].Value);
                string descripcion = filaSel.Cells["descripcion"].Value.ToString();
                string categoria = filaSel.Cells["categoria"].Value.ToString();
                double precio = Convert.ToDouble(filaSel.Cells["precio"].Value);

                txtId.Text = id.ToString();
                txtDescripcion.Text = descripcion;
                txtCategoria.Text = categoria;
                txtPrecio.Text = precio.ToString("N2");
            }
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            resetControl();
        }

        private void resetControl()
        {
            txtId.Text = "0";
            txtDescripcion.Text = "";
            txtCategoria.Text = "";
            txtPrecio.Text = "0.00";

            txtBuscar.Clear();
            dgvProductos.DataSource = null;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text);
            string descripcion = txtDescripcion.Text;
            string categoria = txtCategoria.Text;
            double precio = Convert.ToDouble(txtPrecio.Text);

            ProductoCE productoCE = new ProductoCE(id, descripcion, categoria, precio);
            ProductoCN productoCN = new ProductoCN();

            if (txtId.Text == "0")
            {
                int nuevoId = productoCN.insertar(productoCE);
                if (nuevoId > 0)
                {
                    txtId.Text = nuevoId.ToString();
                    MessageBox.Show("Se ha insertado un nuevo registro");
                }
            }
            else
            {
                bool estado = productoCN.actualizar(productoCE);
                if (estado == true)
                {
                    MessageBox.Show("Se ha actualizado el registro");
                }
            }
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            int id = Convert.ToInt32(txtId.Text);
            if (id != 0)
            {
                DialogResult rpta = MessageBox.Show("Esta a punto " +
                    "de eliminar un registro. Esta seguro?", "Eliminar"
                    , MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation,
                    MessageBoxDefaultButton.Button2);

                ProductoCN productoCN = new ProductoCN();
                if (rpta == DialogResult.Yes)
                {
                    bool estado = productoCN.eliminar(id);
                    MessageBox.Show("Se elimino el registro");
                }
            }
        }

        private void btnCerrar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}