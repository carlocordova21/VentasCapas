﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CapaPresentacion
{
    public partial class PrincipalCP : Form
    {
        public PrincipalCP()
        {
            InitializeComponent();
            //MDI: INTERFAZ DE MULTIPLES DOCUMENTOS
            this.IsMdiContainer = true;
            //Deshabilitar los controles MAX, MIN, REST
            //this.ControlBox = false;
            this.WindowState = FormWindowState.Normal;
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void clientesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ClienteCP.Instancia.MdiParent = this;
            ClienteCP.Instancia.WindowState = FormWindowState.Maximized;
            ClienteCP.Instancia.Show();
        }

        private void productosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            //FormaB -SINGLETON
            //Paso 3: Invoca a la instancia
            ProductoCP.Instancia.MdiParent = this;
            ProductoCP.Instancia.WindowState = FormWindowState.Maximized;
            ProductoCP.Instancia.Show();

            //Forma A - SIN SINGLETON
            //ProductoCP productoCP = new ProductoCP();
            //productoCP.MdiParent = this;
            //productoCP.WindowState = FormWindowState.Maximized;
            //productoCP.Show();
        }

        private void ventasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            VentaDetalleCP.Instancia.MdiParent = this;
            VentaDetalleCP.Instancia.WindowState = FormWindowState.Maximized;
            VentaDetalleCP.Instancia.Show();
        }

        private void PrincipalCP_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult rpta = MessageBox.Show("Esta a punto de cerrar el sistema. " +
                "Esta seguro?", "Advertencia", MessageBoxButtons.YesNo, 
                MessageBoxIcon.Exclamation, MessageBoxDefaultButton.Button2);

            if (rpta == DialogResult.Yes)
            {
                e.Cancel = false;
            } else
            {
                e.Cancel = true;
            }
        }
    }
}
