﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Importar la CapaEntidad
using CapaEntidad;
//Importar las librerias de datos
using System.Data;
//Importar la libreria para SQL Server
using System.Data.SqlClient;
namespace CapaDatos
{
    public class ProductoCD
    {
        //METODOS DEL CRUD
        public ProductoCE buscarId(int id)
        {
            //Establecer conexion
            SqlConnection conexion = ConexionCD.conectarSqlServer();
            conexion.Open();
            SqlCommand cmd = conexion.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from producto where id=@id";

            cmd.Parameters.AddWithValue("@id", id);

            SqlDataReader drProducto = cmd.ExecuteReader();

            ProductoCE productoCE = new ProductoCE();

            if(drProducto.Read())
            {
                productoCE.Id = Convert.ToInt32(drProducto["id"]);
                productoCE.Descripcion = drProducto["descripcion"].ToString();
                productoCE.Categoria = drProducto["categoria"].ToString();
                productoCE.Precio = Convert.ToDouble(drProducto["precio"]);
            } else
            {
                productoCE.Id = 0;
                productoCE.Descripcion = "";
                productoCE.Categoria = "";
                productoCE.Precio = 0;
            }

            conexion.Close();

            return productoCE;
        }

        public List<ProductoCE> buscarDescripcion(string descripcion)
        {
            SqlConnection conexion = ConexionCD.conectarSqlServer();
            conexion.Open();
            SqlCommand cmd = conexion.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "select * from producto where descripcion " +
                "like '%' + @descripcion + '%'";

            cmd.Parameters.AddWithValue("@descripcion", descripcion);
            SqlDataReader drProducto = cmd.ExecuteReader();

            List<ProductoCE> listaProductosCE = new List<ProductoCE>();
            while (drProducto.Read())
            {
                ProductoCE productoCE = new ProductoCE();
                productoCE.Id = Convert.ToInt32(drProducto["id"]);
                productoCE.Descripcion = drProducto["descripcion"].ToString();
                productoCE.Categoria = drProducto["categoria"].ToString();
                productoCE.Precio = Convert.ToDouble(drProducto["precio"]);

                listaProductosCE.Add(productoCE);
            }
            conexion.Close();

            return listaProductosCE;
        }

        public int insertar(ProductoCE productoCE)
        {
            SqlConnection conexion = ConexionCD.conectarSqlServer();
            conexion.Open();
            SqlCommand cmd = conexion.CreateCommand();
            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "insert into producto (descripcion, categoria, precio) " +
                "values (@descripcion, @categoria, @precio)";

            cmd.Parameters.AddWithValue("@descripcion", productoCE.Descripcion);
            cmd.Parameters.AddWithValue("@categoria", productoCE.Categoria);
            cmd.Parameters.AddWithValue("@precio", productoCE.Precio);

            //***************************************
            //Iniciar el controlador de transacciones
            int nuevoId;
            using (SqlTransaction transaction = conexion.BeginTransaction())
            {
                cmd.Transaction = transaction;
                try
                {
                    int nfilas = cmd.ExecuteNonQuery();
                    transaction.Commit();

                    if (nfilas == 0)
                    {
                        nuevoId = 0;
                    }
                    else
                    {
                        cmd.CommandText = "select Max(id) as nuevoId from producto " +
                            "where descripcion=@descripcion";
                        cmd.Parameters["@descripcion"].Value = productoCE.Descripcion;
                        SqlDataReader drProducto = cmd.ExecuteReader();

                        if (drProducto.Read())
                        {
                            nuevoId = Convert.ToInt32(drProducto["nuevoId"]);
                        }
                        else
                        {
                            nuevoId = 0;
                        }
                    }
                }
                catch
                {
                    transaction.Rollback();
                    nuevoId = 0;
                }
            }
            
            conexion.Close();

            return nuevoId;
        }

        public bool actualizar(ProductoCE productoCE)
        {
            SqlConnection conexion = ConexionCD.conectarSqlServer();
            conexion.Open();
            SqlCommand cmd = conexion.CreateCommand();
            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "update producto set descripcion=@descripcion, " +
                "categoria=@categoria, precio=@precio where id=@id";

            cmd.Parameters.AddWithValue("@id", productoCE.Id);
            cmd.Parameters.AddWithValue("@descripcion", productoCE.Descripcion);
            cmd.Parameters.AddWithValue("@categoria", productoCE.Categoria);
            cmd.Parameters.AddWithValue("@precio", productoCE.Precio);

            //***************************************
            //Iniciar el controlador de transacciones
            int nfilas;
            using (SqlTransaction transaction = conexion.BeginTransaction())
            {
                cmd.Transaction = transaction;
                //Controlador de transacciones
                try
                {
                    nfilas = cmd.ExecuteNonQuery();
                    transaction.Commit();
                    
                }
                catch
                {
                    transaction.Rollback();
                    nfilas = 0;
                }
            }

            conexion.Close();

            if (nfilas == 0)
            {
                return false;
            }
            else
            {
                return true;
            }
        }

        public bool eliminar(int id)
        {
            SqlConnection conexion = ConexionCD.conectarSqlServer();
            conexion.Open();
            SqlCommand cmd = conexion.CreateCommand();
            cmd.CommandType = CommandType.Text;

            cmd.CommandText = "delete from producto where id=@id";
            cmd.Parameters.AddWithValue("@id", id);

            //***************************************
            //Iniciar el controlador de transacciones
            int nfilas;
            using (SqlTransaction transaction = conexion.BeginTransaction())
            {
                cmd.Transaction = transaction;
                try
                {
                    nfilas = cmd.ExecuteNonQuery();
                    transaction.Commit();
                }
                catch
                {
                    transaction.Rollback();
                    nfilas = 0;
                }
            }

            conexion.Close();
            
            if (nfilas == 0)
            {
                return false;
            } else
            {
                return true;
            }
        }
    }
}
