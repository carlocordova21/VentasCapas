﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data.SqlClient;
using System.Data;
using CapaEntidad;
namespace CapaDatos
{
    public class VentaCD
    {
        public int insertar(VentaCE ventaCE)
        {
            SqlConnection conexion = ConexionCD.conectarSqlServer();
            conexion.Open();

            SqlCommand cmd = conexion.CreateCommand();
            cmd.CommandType = CommandType.Text;
            cmd.CommandText = "insert into venta(fecventa, idCliente) " +
                "values (@fecventa, @idCliente)";

            cmd.Parameters.AddWithValue("@fecventa", ventaCE.FechaVenta);
            cmd.Parameters.AddWithValue("@idCliente", ventaCE.IdCliente);

            //******************************
            //Iniciar el control de transacciones
            //******************************
            int nuevoId;
            using (SqlTransaction transaction = conexion.BeginTransaction())
            {
                cmd.Transaction = transaction;
                //Controlador de Excepciones
                try
                {
                    //Ejecutar el comando
                    int nfilas = cmd.ExecuteNonQuery();//SQL> UPDATE, INSERT, DELETE
                    //Confirmar la transaccion
                    transaction.Commit();

                    if (nfilas == 0)
                    {
                        nuevoId = 0;
                    }
                    else
                    {
                        cmd.CommandText = "select max(id) as nuevoId from venta " +
                            "where idCliente = @idCliente";

                        cmd.Parameters["@idCliente"].Value = ventaCE.IdCliente;
                        SqlDataReader drVenta = cmd.ExecuteReader();
                        if (drVenta.Read())
                        {
                            nuevoId = Convert.ToInt32(drVenta["nuevoId"]);
                        }
                        else
                        {
                            nuevoId = 0;
                        }
                    }
                }
                catch
                {
                    //Deshacer la transaccion
                    transaction.Rollback();
                    nuevoId = 0;
                }
            }

           //Cerrar la conexion
            conexion.Close();

            return nuevoId;
        }
    }
}
